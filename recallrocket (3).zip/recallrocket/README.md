# RecallRocket

Spaced-repetition flashcards built on the SM-2 algorithm, with daily streaks, stats and a campus leaderboard.

## Run it
```
npm install
npm start
```
Open http://localhost:3000. Run the tests with `npm test`.

## Features
- SM-2 scheduling (grades 0-5, ease factor floored at 1.3). A missed card (grade < 3) keeps its ease factor and comes back at the end of the same session.
- Rating buttons are labelled and show the next interval
- 3D flip card; Space or Enter flips, 0-5 rates
- Daily due queue, deck + card creation with live preview
- Edit and delete cards, CSV export and import (`deck,question,answer`)
- Stats: totals, 30-day recall rate, new/learning/mature counts, 14-day review chart
- Streak counter (learner's local date), leaderboard via Express
- Dark mode (follows the system setting first), read-aloud with the Web Speech API
- 40 seeded CS interview cards

## Layout
- `server.js`: Express API (`GET /api/leaderboard`, `POST /api/sync`) with a rate limit
- `leaderboard.js`: leaderboard storage and validation (atomic file writes)
- `public/sm2.js`: SM-2 logic, shared by the browser and the tests
- `public/app.js`: front end

## Leaderboard security
Each browser gets a random id and secret. The server stores only a hash of the secret, so nobody else can overwrite your row. It also rejects impossible scores (points beyond 15 per review, or sudden jumps). This deters casual cheating, but reviews are still reported by the client. Stopping a determined cheater would need the server to log reviews itself.

Rows in an old `data.json` from version 1.0 stay visible but can't be claimed; users reappear under their new id on their next sync.
