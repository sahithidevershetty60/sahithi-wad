// SM-2 scheduling, shared by the browser (window.SM2) and the tests (require).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.SM2 = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  // card: { interval, reps, ef }, grade: 0-5. Returns the new { interval, reps, ef }.
  // A lapse (grade < 3) restarts the repetitions but leaves the ease factor
  // untouched, as in the original SM-2 description.
  function review(card, grade) {
    let { interval, reps, ef } = card;
    if (grade < 3) {
      return { interval: 1, reps: 0, ef };
    }
    if (reps === 0) interval = 1;
    else if (reps === 1) interval = 6;
    else interval = Math.round(interval * ef);
    reps += 1;
    ef = ef + (0.1 - (5 - grade) * (0.08 + (5 - grade) * 0.02));
    if (ef < 1.3) ef = 1.3; // floor from the SM-2 spec
    return { interval, reps, ef: +ef.toFixed(2) };
  }
  return { review };
});
