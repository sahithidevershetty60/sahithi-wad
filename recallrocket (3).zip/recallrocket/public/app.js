// RecallRocket: SM-2 flashcards, streaks, stats and leaderboard.
const $ = s => document.querySelector(s);
const KEY = 'recallrocket.v1';
const GRADES = ['Blackout', 'Wrong', 'Close', 'Hard', 'Good', 'Easy'];

// Dates are plain YYYY-MM-DD strings in the learner's local time, so the day
// (and the streak) rolls over at local midnight. Day arithmetic is calendar-only.
function today() {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}
function addDays(n, from = today()) {
  const d = new Date(from + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
const rid = () => [...crypto.getRandomValues(new Uint8Array(16))].map(b => b.toString(16).padStart(2, '0')).join('');
const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');

/* ---------- state ---------- */
function freshState() {
  return {
    name: 'Student ' + (1000 + Math.floor(Math.random() * 9000)),
    theme: matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light',
    days: [], log: {}, reviewed: 0, points: 0,
    cards: SEED.map(([deck, q, a], i) => ({ id: i + 1, deck, q, a, interval: 0, reps: 0, ef: 2.5, due: today() }))
  };
}
let S;
try { S = JSON.parse(localStorage.getItem(KEY)); } catch { S = null; }
if (!S || !Array.isArray(S.cards)) S = freshState();
S.id = S.id || rid();          // leaderboard identity; the secret proves it's still you
S.secret = S.secret || rid();
S.log = S.log || {};
S.days = S.days || [];
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(S)); }
  catch { alert('Browser storage is full, so your latest changes were not saved. Export a CSV and delete unused cards.'); }
}

function streak() {
  const set = new Set(S.days);
  let day = set.has(today()) ? today() : addDays(-1);
  let n = 0;
  while (set.has(day)) { n++; day = addDays(-1, day); }
  return n;
}

/* ---------- tiny rich text ---------- */
function fmt(t) {
  return esc(t).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/`(.+?)`/g, '<code>$1</code>').replace(/\n/g, '<br>');
}
const plain = t => t.replace(/[*`]/g, '');

/* ---------- study view ---------- */
let queue = [], current = null, flipped = false;
const lapsed = new Set(); // card ids missed this session: they come back, but earn no points

function decks() { return [...new Set(S.cards.map(c => c.deck))]; }

function buildQueue() {
  const d = $('#deckPick').value;
  lapsed.clear();
  queue = S.cards.filter(c => c.due <= today() && (d === 'all' || c.deck === d));
  next();
}

function next() {
  current = queue[0] || null;
  flipped = false;
  $('#card').classList.remove('flipped');
  $('#rate').classList.add('hidden');
  $('#dueInfo').textContent = `${queue.length} due today`;
  if (!current) {
    $('#front').innerHTML = '🎉 All caught up!<br>Come back tomorrow.';
    $('#back').innerHTML = '';
    return;
  }
  $('#front').innerHTML = fmt(current.q) + '<button class="say" data-t="q" aria-label="Read question aloud">🔊</button>';
  $('#back').innerHTML = fmt(current.a) + '<button class="say" data-t="a" aria-label="Read answer aloud">🔊</button>';
  $('#rate').innerHTML = GRADES.map((label, g) =>
    `<button data-g="${g}"><span><b>${g}</b> ${label}</span><small>${g < 3 ? 'again' : SM2.review(current, g).interval + 'd'}</small></button>`
  ).join('');
}

function flip() {
  if (!current) return;
  flipped = !flipped;
  $('#card').classList.toggle('flipped', flipped);
  $('#rate').classList.toggle('hidden', !flipped);
}

function rate(g) {
  if (!current || !flipped) return;
  const i = S.cards.findIndex(c => c.id === current.id);
  const r = SM2.review(S.cards[i], g);
  const upd = S.cards[i] = { ...S.cards[i], ...r, due: addDays(r.interval) };

  S.reviewed++;
  if (g >= 3 && !lapsed.has(upd.id)) S.points += 10 + g;
  const L = S.log[today()] = S.log[today()] || { n: 0, ok: 0 };
  L.n++; if (g >= 3) L.ok++;
  if (!S.days.includes(today())) {
    S.days.push(today());
    const el = $('#streak'); el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop');
  }
  save();

  queue.shift();
  if (g < 3) {            // missed cards return at the end of this session
    lapsed.add(upd.id);
    queue.push(upd);
    $('#msg').textContent = 'Missed. This card will come back before you finish.';
  } else {
    $('#msg').textContent = `Next review in ${upd.interval} day${upd.interval === 1 ? '' : 's'} (EF ${upd.ef})`;
  }
  renderStreak();
  next();
  sync();
}

let streakTimer;
function renderStreak() {
  clearInterval(streakTimer);
  const target = streak(), el = $('#streakNum');
  let n = +el.textContent || 0;
  if (n === target) { el.textContent = n; return; }
  streakTimer = setInterval(() => {
    n += n < target ? 1 : -1;
    el.textContent = n;
    if (n === target) clearInterval(streakTimer);
  }, 60);
}

function speak(text) {
  if (!('speechSynthesis' in window)) return;
  speechSynthesis.cancel();
  speechSynthesis.speak(new SpeechSynthesisUtterance(plain(text)));
}

/* ---------- decks view ---------- */
let editingId = null;

function renderDecks() {
  $('#deckList').innerHTML = decks().map(d => `<option value="${esc(d)}">`).join('');
  $('#deckList2').innerHTML = decks().map(d => {
    const all = S.cards.filter(c => c.deck === d);
    const due = all.filter(c => c.due <= today()).length;
    const rows = all.map(c => `<div class="cardrow"><span>${esc(plain(c.q))}</span>
      <div><button class="small" data-act="edit" data-id="${c.id}">Edit</button>
      <button class="small danger" data-act="del" data-id="${c.id}">Delete</button></div></div>`).join('');
    return `<details class="deckrow"><summary><span>${esc(d)}</span><span>${all.length} cards · ${due} due</span></summary>${rows}</details>`;
  }).join('');
  const pick = $('#deckPick'), keep = pick.value;
  pick.innerHTML = '<option value="all">All decks</option>' + decks().map(d => `<option value="${esc(d)}">${esc(d)}</option>`).join('');
  pick.value = [...pick.options].some(o => o.value === keep) ? keep : 'all';
}

function setEditing(card) {
  editingId = card ? card.id : null;
  $('#formTitle').textContent = card ? 'Edit card' : 'Add a card';
  $('#addCard').textContent = card ? 'Save changes' : 'Add card';
  $('#cancelEdit').classList.toggle('hidden', !card);
  $('#newDeck').value = card ? card.deck : '';
  $('#newQ').value = card ? card.q : '';
  $('#newA').value = card ? card.a : '';
  preview();
  if (card) $('#formTitle').scrollIntoView({ behavior: 'smooth' });
}

$('#deckList2').onclick = e => {
  const b = e.target.closest('button[data-act]');
  if (!b) return;
  const card = S.cards.find(c => c.id === +b.dataset.id);
  if (!card) return;
  if (b.dataset.act === 'edit') return setEditing(card);
  if (!confirm('Delete this card? Its review history is lost.')) return;
  S.cards = S.cards.filter(c => c.id !== card.id);
  if (editingId === card.id) setEditing(null);
  save(); renderDecks();
};
$('#cancelEdit').onclick = () => setEditing(null);

function exportCsv() {
  const esc2 = v => '"' + String(v).replace(/"/g, '""') + '"';
  const rows = S.cards.map(c => [c.deck, c.q, c.a].map(esc2).join(','));
  const blob = new Blob(['deck,question,answer\n' + rows.join('\n')], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'recallrocket.csv'; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// Minimal RFC 4180 parser: quoted fields, doubled quotes, newlines inside quotes.
function parseCsv(text) {
  const rows = []; let row = [], f = '', q = false;
  text = text.replace(/^\uFEFF/, '');
  const endRow = () => { row.push(f); f = ''; if (row.some(x => x.trim())) rows.push(row); row = []; };
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; }
      else f += c;
    } else if (c === '"') q = true;
    else if (c === ',') { row.push(f); f = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; endRow(); }
    else f += c;
  }
  if (f !== '' || row.length) endRow();
  return rows;
}

function importCsv(text) {
  let rows = parseCsv(text);
  if (rows[0] && rows[0].map(x => x.trim().toLowerCase()).join() === 'deck,question,answer') rows = rows.slice(1);
  const have = new Set(S.cards.map(c => c.deck + '\u0000' + c.q));
  let added = 0, skipped = 0, id = Math.max(0, ...S.cards.map(c => c.id)) + 1;
  for (const r of rows) {
    const [deck, q, a] = (r.length >= 3 ? r : []).map(x => x.trim());
    const dupe = have.has(deck + '\u0000' + q);
    if (!deck || !q || !a || dupe || added >= 5000) { skipped++; continue; }
    S.cards.push({ id: id++, deck, q, a, interval: 0, reps: 0, ef: 2.5, due: today() });
    have.add(deck + '\u0000' + q); added++;
  }
  save(); renderDecks();
  $('#deckMsg').textContent = `Imported ${added} card${added === 1 ? '' : 's'}` + (skipped ? `, skipped ${skipped} (missing fields or duplicates).` : '.');
}
$('#importBtn').onclick = () => $('#importCsv').click();
$('#importCsv').onchange = async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (file) importCsv(await file.text());
};

/* ---------- stats view ---------- */
function renderStats() {
  const days = Array.from({ length: 14 }, (_, i) => addDays(i - 13));
  const counts = days.map(d => (S.log[d] ? S.log[d].n : 0));
  const max = Math.max(1, ...counts);
  $('#bars').setAttribute('role', 'img');
  $('#bars').setAttribute('aria-label', 'Reviews per day, last 14 days: ' + counts.join(', '));
  $('#bars').innerHTML = days.map((d, i) =>
    `<div class="col" title="${d}: ${counts[i]} reviews">${counts[i] || ''}<i style="height:${Math.round(counts[i] / max * 100)}%"></i>${+d.slice(8)}</div>`).join('');

  const last30 = Object.entries(S.log).filter(([d]) => d >= addDays(-29));
  const n = last30.reduce((s, [, v]) => s + v.n, 0), ok = last30.reduce((s, [, v]) => s + v.ok, 0);
  const fresh = S.cards.filter(c => c.reps === 0 && c.interval === 0).length;
  const mature = S.cards.filter(c => c.interval >= 21).length;
  const tiles = [
    [S.reviewed, 'reviews in total'], [streak(), 'day streak'], [S.points, 'points'],
    [n ? Math.round(ok / n * 100) + '%' : '–', 'recalled, last 30 days'],
    [fresh, 'new cards'], [S.cards.length - fresh - mature, 'learning'], [mature, 'mature (21+ day interval)']
  ];
  $('#statTiles').innerHTML = tiles.map(([v, l]) => `<div class="tile"><b>${v}</b><span>${l}</span></div>`).join('');
}

/* ---------- leaderboard ---------- */
let syncTimer;
function sync(now) {
  clearTimeout(syncTimer);
  if (now) return doSync();
  syncTimer = setTimeout(doSync, 4000); // batch rapid ratings into one request
}
async function doSync() {
  try {
    const r = await fetch('/api/sync', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: S.id, secret: S.secret, name: S.name, reviewed: S.reviewed, streak: streak(), points: S.points })
    });
    if (r.ok) return '';
    return (await r.json()).error || 'The server rejected the sync.';
  } catch { return null; } // offline is fine
}

async function renderBoard() {
  let users;
  try {
    const problem = await doSync();
    const r = await fetch('/api/leaderboard?id=' + encodeURIComponent(S.id));
    if (!r.ok) throw new Error();
    users = await r.json();
    $('#offline').textContent = problem ? `Your score was not updated: ${problem}` : '';
  } catch {
    $('#offline').textContent = 'Server not reachable, showing only you. Run `npm start` for the full board.';
    users = [{ rank: 1, name: S.name, reviewed: S.reviewed, streak: streak(), points: S.points, me: true }];
  }
  $('#rows').innerHTML = users.map(u =>
    `<tr class="${u.me ? 'me' : ''}"><td>${u.rank}</td><td>${esc(u.name)}${u.me ? ' (you)' : ''}</td><td>${u.reviewed}</td><td>🔥 ${u.streak}</td><td>${u.points}</td></tr>`
  ).join('');
}

/* ---------- wiring ---------- */
function show(view) {
  document.querySelectorAll('main section').forEach(s => s.classList.toggle('hidden', s.id !== view));
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.view === view));
  if (view === 'board') renderBoard();
  if (view === 'decks') renderDecks();
  if (view === 'stats') renderStats();
  if (view === 'study') buildQueue();
}

document.querySelectorAll('nav button').forEach(b => b.onclick = () => show(b.dataset.view));
$('#scene').onclick = e => {
  const say = e.target.closest('.say');
  if (say) { e.stopPropagation(); speak(say.dataset.t === 'a' ? current.a : current.q); return; }
  flip();
};
$('#deckPick').onchange = buildQueue;
$('#rate').onclick = e => { const b = e.target.closest('button[data-g]'); if (b) rate(+b.dataset.g); };

document.addEventListener('keydown', e => {
  if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  if ($('#study').classList.contains('hidden')) return;
  if (e.code === 'Space' || (e.key === 'Enter' && e.target.id === 'scene')) { e.preventDefault(); flip(); }
  else if (/^[0-5]$/.test(e.key)) rate(+e.key);
});

const preview = () => { $('#pvQ').innerHTML = fmt($('#newQ').value); $('#pvA').innerHTML = fmt($('#newA').value); };
$('#newQ').oninput = preview; $('#newA').oninput = preview;
$('#addCard').onclick = () => {
  const deck = $('#newDeck').value.trim(), q = $('#newQ').value.trim(), a = $('#newA').value.trim();
  if (!deck || !q || !a) return alert('Fill in deck, question and answer.');
  if (editingId) {
    const c = S.cards.find(x => x.id === editingId);
    if (c) Object.assign(c, { deck, q, a }); // scheduling stays as it was
    $('#deckMsg').textContent = 'Card saved.';
    setEditing(null);
  } else {
    S.cards.push({ id: Math.max(0, ...S.cards.map(c => c.id)) + 1, deck, q, a, interval: 0, reps: 0, ef: 2.5, due: today() });
    $('#newQ').value = $('#newA').value = '';
    $('#deckMsg').textContent = 'Card added.';
    preview();
  }
  save(); renderDecks();
};
$('#exportCsv').onclick = exportCsv;

$('#myName').value = S.name;
$('#myName').onchange = e => { S.name = e.target.value.trim() || S.name; e.target.value = S.name; save(); renderBoard(); };

function applyTheme() { document.documentElement.dataset.theme = S.theme; }
$('#theme').onclick = () => { S.theme = S.theme === 'dark' ? 'light' : 'dark'; save(); applyTheme(); };

applyTheme();
renderDecks();
$('#streakNum').textContent = streak();
buildQueue();
