// Leaderboard storage + validation, kept separate from Express so it can be tested.
'use strict';
const fs = require('fs');
const crypto = require('crypto');

const MAX_POINTS_PER_REVIEW = 15;   // the app awards 10 + grade, grade <= 5
const MAX_FIRST_SYNC_REVIEWS = 5000;
const ID_RE = /^[A-Za-z0-9_-]{16,64}$/;

const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const fail = (status, error) => ({ status, body: { error } });

const PEERS = [
  { id: 'peer-aarav', name: 'Aarav', reviewed: 212, streak: 9, points: 1840 },
  { id: 'peer-meera', name: 'Meera', reviewed: 175, streak: 14, points: 1710 },
  { id: 'peer-rohan', name: 'Rohan', reviewed: 130, streak: 4, points: 990 },
  { id: 'peer-sneha', name: 'Sneha', reviewed: 98, streak: 6, points: 905 },
  { id: 'peer-kabir', name: 'Kabir', reviewed: 60, streak: 2, points: 410 },
];

class Leaderboard {
  constructor(file, { now = Date.now } = {}) {
    this.file = file;
    this.now = now;
    this.timer = null;
    this.users = this._load();
  }

  _load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      if (Array.isArray(raw)) {
        // Rows from the old format have no id/secret; they stay visible but can't be claimed.
        return raw.map(u => (u.id ? u : { ...u, id: 'legacy-' + u.name }));
      }
    } catch { /* no file yet */ }
    return PEERS.map(p => ({ ...p }));
  }

  _schedule() {
    if (this.timer) return;
    this.timer = setTimeout(() => this.flush(), 500);
    if (this.timer.unref) this.timer.unref();
  }

  flush() {
    clearTimeout(this.timer);
    this.timer = null;
    try {
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.users, null, 2));
      fs.renameSync(tmp, this.file); // atomic replace, so a crash never leaves half a file
    } catch (e) {
      console.error('Could not save leaderboard:', e.message);
    }
  }

  top(meId, limit = 50) {
    const ranked = this.users
      .slice()
      .sort((a, b) => b.points - a.points || b.streak - a.streak || a.name.localeCompare(b.name))
      .map((u, i) => ({ rank: i + 1, name: u.name, reviewed: u.reviewed, streak: u.streak, points: u.points, me: u.id === meId }));
    const rows = ranked.slice(0, limit);
    const me = ranked.find(r => r.me);
    if (me && !rows.includes(me)) rows.push(me);
    return rows;
  }

  // Returns { status, body }.
  sync(b) {
    b = b && typeof b === 'object' ? b : {};
    const { id, secret } = b;
    if (typeof id !== 'string' || !ID_RE.test(id) || typeof secret !== 'string' || !ID_RE.test(secret)) {
      return fail(400, 'id and secret are required');
    }
    const name = typeof b.name === 'string' ? b.name.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 20) : '';
    if (!name) return fail(400, 'name is required');

    const { reviewed, streak, points } = b;
    if (![reviewed, streak, points].every(n => Number.isInteger(n) && n >= 0)) {
      return fail(400, 'reviewed, streak and points must be whole numbers, 0 or more');
    }
    if (streak > 36500) return fail(422, 'streak is not plausible');
    if (points > MAX_POINTS_PER_REVIEW * reviewed) return fail(422, 'points are more than that many reviews can earn');

    const now = this.now();
    const hash = sha(secret);
    const i = this.users.findIndex(u => u.id === id);

    if (i < 0) {
      if (reviewed > MAX_FIRST_SYNC_REVIEWS) return fail(422, 'reviewed is not plausible for a first sync');
      this.users.push({ id, secretHash: hash, name, reviewed, streak, points, updatedAt: now });
    } else {
      const u = this.users[i];
      const ok = u.secretHash && crypto.timingSafeEqual(Buffer.from(u.secretHash, 'hex'), Buffer.from(hash, 'hex'));
      if (!ok) return fail(403, 'this id belongs to someone else');
      const dr = reviewed - u.reviewed;
      const dp = points - u.points;
      const days = Math.max(0, (now - (u.updatedAt || 0)) / 864e5);
      if (dr > 100 + 1000 * days) return fail(422, 'reviewed grew faster than is plausible');
      if (dp > MAX_POINTS_PER_REVIEW * Math.max(dr, 0)) return fail(422, 'points grew faster than reviews allow');
      this.users[i] = { ...u, name, reviewed, streak, points, updatedAt: now };
    }
    this._schedule();
    return { status: 200, body: { ok: true } };
  }
}

module.exports = { Leaderboard, MAX_POINTS_PER_REVIEW };
