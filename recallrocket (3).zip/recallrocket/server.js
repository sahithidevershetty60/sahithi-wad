// Express server: serves the app and keeps a shared leaderboard in a JSON file.
const express = require('express');
const path = require('path');
const { Leaderboard } = require('./leaderboard');

const app = express();
const PORT = process.env.PORT || 3000;
const board = new Leaderboard(path.join(process.env.DATA_DIR || __dirname, 'data.json'));

// Very small rate limit: 60 syncs per minute per IP, counters reset every minute.
const hits = new Map();
setInterval(() => hits.clear(), 60 * 1000).unref();
function limit(req, res, next) {
  const n = (hits.get(req.ip) || 0) + 1;
  hits.set(req.ip, n);
  if (n > 60) return res.status(429).json({ error: 'too many requests, try again in a minute' });
  next();
}

app.disable('x-powered-by');
app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/leaderboard', (req, res) => {
  res.json(board.top(typeof req.query.id === 'string' ? req.query.id : ''));
});

app.post('/api/sync', limit, (req, res) => {
  const { status, body } = board.sync(req.body);
  res.status(status).json(body);
});

app.use((err, req, res, next) => {
  res.status(err.status || 500).json({ error: err.status === 400 ? 'invalid JSON' : 'server error' });
});

const server = app.listen(PORT, () => console.log(`RecallRocket running at http://localhost:${PORT}`));
for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => { board.flush(); server.close(); process.exit(0); });
}
