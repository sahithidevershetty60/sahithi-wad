const test = require('node:test');
const assert = require('node:assert');
const { review } = require('../public/sm2');

const fresh = { interval: 0, reps: 0, ef: 2.5 };

test('first two successes give 1 then 6 days', () => {
  const a = review(fresh, 4);
  assert.deepStrictEqual([a.interval, a.reps], [1, 1]);
  const b = review(a, 4);
  assert.deepStrictEqual([b.interval, b.reps], [6, 2]);
});

test('later intervals multiply by the ease factor', () => {
  const c = review({ interval: 6, reps: 2, ef: 2.5 }, 5);
  assert.strictEqual(c.interval, 15);
  assert.strictEqual(c.ef, 2.6);
});

test('a lapse resets reps and interval but keeps the ease factor', () => {
  const r = review({ interval: 30, reps: 5, ef: 2.1 }, 1);
  assert.deepStrictEqual(r, { interval: 1, reps: 0, ef: 2.1 });
});

test('ease factor never drops below 1.3', () => {
  let c = { interval: 6, reps: 2, ef: 1.35 };
  for (let i = 0; i < 5; i++) c = review(c, 3);
  assert.strictEqual(c.ef, 1.3);
});
