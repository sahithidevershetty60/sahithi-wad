const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path');
const { Leaderboard } = require('../leaderboard');

const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'rr-')), 'data.json');
const ID = 'a'.repeat(32), SECRET = 'b'.repeat(32);
const body = (o = {}) => ({ id: ID, secret: SECRET, name: 'Test', reviewed: 10, streak: 1, points: 120, ...o });

test('starts with the demo peers when there is no file', () => {
  assert.strictEqual(new Leaderboard(tmp()).top('').length, 5);
});

test('accepts a new user and ranks them', () => {
  const b = new Leaderboard(tmp());
  assert.strictEqual(b.sync(body({ points: 2000, reviewed: 200 })).status, 200);
  const rows = b.top(ID);
  assert.strictEqual(rows[0].name, 'Test');
  assert.strictEqual(rows[0].me, true);
});

test('another client cannot overwrite an existing id', () => {
  const b = new Leaderboard(tmp());
  b.sync(body());
  assert.strictEqual(b.sync(body({ secret: 'c'.repeat(32), points: 0 })).status, 403);
});

test('peers and legacy rows cannot be claimed', () => {
  const b = new Leaderboard(tmp());
  assert.strictEqual(b.sync(body({ id: 'peer-aarav' })).status, 400);
});

test('rejects impossible points and non-integer input', () => {
  const b = new Leaderboard(tmp());
  assert.strictEqual(b.sync(body({ points: 99999 })).status, 422);
  assert.strictEqual(b.sync(body({ reviewed: '10' })).status, 400);
  assert.strictEqual(b.sync(body({ name: '   ' })).status, 400);
});

test('rejects sudden jumps in points or reviews', () => {
  const b = new Leaderboard(tmp());
  b.sync(body());
  assert.strictEqual(b.sync(body({ reviewed: 10, points: 150 })).status, 422);       // points without reviews
  assert.strictEqual(b.sync(body({ reviewed: 5000, points: 5000 })).status, 422);    // reviews too fast
  assert.strictEqual(b.sync(body({ reviewed: 20, points: 250 })).status, 200);       // normal progress
});

test('persists to disk atomically', () => {
  const file = tmp();
  const b = new Leaderboard(file);
  b.sync(body());
  b.flush();
  assert.ok(JSON.parse(fs.readFileSync(file, 'utf8')).some(u => u.id === ID));
  assert.ok(!fs.existsSync(file + '.tmp'));
});
